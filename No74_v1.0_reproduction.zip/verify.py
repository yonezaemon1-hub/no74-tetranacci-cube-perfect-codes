from itertools import combinations, product


def allowed(s):
    return '1111' not in s


def flip(s, j):
    return s[:j] + ('0' if s[j] == '1' else '1') + s[j + 1:]


def boundary(f, w, choices):
    assert not allowed(f) and allowed(w)
    assert [flip(w, j) for j in range(len(w)) if not allowed(flip(w, j))] == [f]
    possible = {j + 1 for j in range(len(f)) if allowed(flip(f, j))}
    assert possible and possible <= choices


def verify_family(rows, choices):
    assert len(rows) > len(choices)
    for f, w in rows:
        boundary(f, w, choices)
    for (f, _), (g, _) in combinations(rows, 2):
        assert 1 <= sum(a != b for a, b in zip(f, g)) <= 2


def exact_cover(n):
    V = [x for x in range(1 << n) if not (x & (x >> 1) & (x >> 2) & (x >> 3))]
    idx = {x: i for i, x in enumerate(V)}
    B = [sum(1 << idx[y] for y in [x] + [x ^ (1 << j) for j in range(n)] if y in idx) for x in V]
    candidates = [[j for j, b in enumerate(B) if (b >> i) & 1] for i in range(len(V))]
    calls = 0
    def dfs(R):
        nonlocal calls
        calls += 1
        if not R:
            return []
        options = None
        z = R
        while z:
            bit = z & -z
            z ^= bit
            i = bit.bit_length() - 1
            op = [j for j in candidates[i] if B[j] & R == B[j]]
            if not op:
                return None
            if options is None or len(op) < len(options):
                options = op
            if len(options) == 1:
                break
        for j in options:
            ans = dfs(R ^ B[j])
            if ans is not None:
                return [V[j]] + ans
        return None
    ans = dfs((1 << len(V)) - 1)
    if ans is not None:
        assert all(sum((x ^ c).bit_count() <= 1 for c in ans) == 1 for x in V)
    return len(V), calls, ans is not None


def main():
    rows7 = [('11111' + ''.join(t), '11101' + ''.join(t)) for t in product('01', repeat=2)]
    verify_family(rows7, {2, 3, 4})
    print('PASS n=7: 4 forbidden vertices, 3 flip positions')
    rows8 = [('11110000','11010000'), ('11110001','11010001'), ('11110011','11010011'), ('11110101','11010101'), ('11111001','11011001')]
    for n in range(8, 41):
        verify_family([(f+'0'*(n-8), w+'0'*(n-8)) for f,w in rows8], {1,2,3,4})
    print('PASS n=8..40: local obstruction checks (finite corroboration only)')
    for n in range(1, 8):
        v, calls, exists = exact_cover(n)
        assert exists == (n in (1,3))
        print(f'n={n} vertices={v} calls={calls} exists={exists}')
    print('FINAL: PASS LOCAL AND FINITE CHECKS; INDEPENDENT AUDIT PENDING')


if __name__ == '__main__':
    main()
