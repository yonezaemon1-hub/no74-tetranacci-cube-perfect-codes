from pathlib import Path
import hashlib
p = Path(__file__).resolve().parent
expected = {}
for line in (p / "SHA256SUMS.txt").read_text(encoding="ascii").splitlines():
    digest, name = line.split("  ", 1)
    assert name not in expected and "/" not in name and "\\" not in name
    expected[name] = digest
assert set(expected) == {"verify.py", "EXPECTED_RESULTS.txt", "README.txt", "verify_manifest.py"}
assert {f.name for f in p.iterdir()} == set(expected) | {"SHA256SUMS.txt"}
for name, digest in expected.items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, name
print("PASS PUBLIC_REPRO_ALLOWLIST_SHA256 4")
